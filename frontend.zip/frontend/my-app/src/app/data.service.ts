import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private apiRiskUrl = 'http://localhost:5555/riskdata'; // Replace this with your API endpoint URL
  private apiSourceUrl = 'http://localhost:5555/risksource';
  private apiCategoryUrl = 'http://localhost:5555/riskcat';
  private apiModelUrl = 'http://localhost:5555/risk_assessment_models';
  private apiMarketUrl = 'http://localhost:5555/market_data';


  constructor(private http: HttpClient) { }

  getRiskData(): Observable<any> {
    return this.http.get<any>(this.apiRiskUrl);
  }
  getSourceData(): Observable<any> {
    return this.http.get<any>(this.apiSourceUrl);
  }
  getCategoryData(): Observable<any> {
    return this.http.get<any>(this.apiCategoryUrl);
  }
  getModelData(): Observable<any> {
    return this.http.get<any>(this.apiModelUrl);
  }
  getMarketData(): Observable<any> {
    return this.http.get<any>(this.apiMarketUrl);
  }


}
