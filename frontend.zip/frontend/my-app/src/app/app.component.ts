import { Component } from '@angular/core';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  riskdata: any;
  sourcedata: any;
  categorydata: any;
  modeldata: any;
  marketdata: any;

  constructor(private dataService: DataService) { }
  ngOnInit(): void {
  this.dataService.getRiskData().subscribe(
    (response) => {
      this.riskdata = response.results;
      console.log(this.riskdata); // You can do something with the data here
    },
    (error) => {
      console.error('Error fetching data:', error);
    }
  );
  this.dataService.getSourceData().subscribe(
    (response) => {
      this.sourcedata = response.results;
      console.log(this.sourcedata); // You can do something with the data here
    },
    (error) => {
      console.error('Error fetching data:', error);
    }
  );

  this.dataService.getCategoryData().subscribe(
    (response) => {
      this.categorydata = response.results;
      console.log(this.categorydata); // You can do something with the data here
    },
    (error) => {
      console.error('Error fetching data:', error);
    }
  );

  this.dataService.getModelData().subscribe(
    (response) => {
      this.modeldata = response.results;
      console.log(this.modeldata); // You can do something with the data here
    },
    (error) => {
      console.error('Error fetching data:', error);
    }
  );

  this.dataService.getMarketData().subscribe(
    (response) => {
      this.marketdata = response.results;
      console.log(this.marketdata); // You can do something with the data here
    },
    (error) => {
      console.error('Error fetching data:', error);
    }
  );
  }
  title = 'my-app';
}
